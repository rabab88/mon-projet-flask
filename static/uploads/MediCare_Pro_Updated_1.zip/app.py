from flask import Flask, render_template, redirect, url_for, request
from utils import generate_user_id, generate_qr_code, Blockchain, SmartContract
from forms import RegistrationForm, LoginForm, LabSubmissionForm
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mysecretkey'

# Initialize Blockchain
blockchain = Blockchain()
smart_contract = SmartContract()

@app.route("/", methods=["GET"])
def home():
    return render_template("home.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        user_data = {
            'type': 'registration',
            'name': form.name.data,
            'national_id': form.national_id.data,
            'phone': form.phone.data,
            'birth_date': form.birth_date.data.strftime('%Y-%m-%d'),
            'profession': form.profession.data
        }
        # Validate with Smart Contract
        is_valid, message = smart_contract.validate_registration(user_data, blockchain)
        if not is_valid:
            return render_template("register.html", form=form, error=message)
        
        user_id = generate_user_id()
        user_data['user_id'] = user_id
        qr_path = generate_qr_code(user_id)
        blockchain.add_block(user_data)
        return render_template("user_profile.html", user_id=user_id, qr_path=qr_path)
    
    return render_template("register.html", form=form)

@app.route("/login", methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user_id = form.user_id.data
        profession = form.profession.data
        if profession == 'doctor':
            return redirect(url_for('doctor', user_id=user_id))
        elif profession == 'patient':
            return redirect(url_for('patient', user_id=user_id))
        elif profession == 'pharmacist':
            return redirect(url_for('pharmacist', user_id=user_id))
        elif profession == 'lab':
            return redirect(url_for('lab', user_id=user_id))
    
    return render_template('login.html', form=form)

@app.route('/doctor/<user_id>')
def doctor(user_id):
    return render_template('doctor.html', user_id=user_id)

@app.route('/patient/<user_id>')
def patient(user_id):
    return render_template('patient.html', user_id=user_id)

@app.route('/pharmacist/<user_id>')
def pharmacist(user_id):
    return render_template('pharmacist.html', user_id=user_id)

@app.route('/lab/<user_id>', methods=["GET", "POST"])
def lab(user_id):
    form = LabSubmissionForm()
    if form.validate_on_submit():
        submission_data = {
            'type': 'lab_submission',
            'lab_user_id': user_id,
            'patient_id': form.patient_id.data,
            'test_type': form.test_type.data,
            'result': form.result.data,
            'submission_date': datetime.now().isoformat()
        }
        # Validate with Smart Contract
        is_valid, message = smart_contract.validate_lab_submission(submission_data, blockchain)
        if not is_valid:
            return render_template("lab.html", form=form, user_id=user_id, error=message)
        
        blockchain.add_block(submission_data)
        return render_template("lab.html", form=form, user_id=user_id, success="Lab submission recorded")
    
    return render_template('lab.html', form=form, user_id=user_id)

@app.route("/blockchain")
def blockchain_view():
    return render_template("blockchain.html", blockchain=blockchain.chain)

if __name__ == "__main__":
    app.run(debug=True)