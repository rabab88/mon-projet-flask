import os
import qrcode
import uuid
import hashlib
import json
from datetime import datetime

def generate_user_id():
    return str(uuid.uuid4())

def generate_qr_code(user_id):
    qr_code_dir = 'static/qr_codes'
    if not os.path.exists(qr_code_dir):
        os.makedirs(qr_code_dir)
    img = qrcode.make(user_id)
    file_path = os.path.join(qr_code_dir, f"{user_id}.png")
    img.save(file_path)
    return file_path

class Block:
    def __init__(self, index, timestamp, data, previous_hash):
        self.index = index
        self.timestamp = timestamp
        self.data = data
        self.previous_hash = previous_hash
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        block_string = json.dumps({
            'index': self.index,
            'timestamp': self.timestamp,
            'data': self.data,
            'previous_hash': self.previous_hash
        }, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()

class Blockchain:
    def __init__(self):
        self.chain = []
        self.data_dir = 'data'
        self.blockchain_file = os.path.join(self.data_dir, 'blockchain.json')
        self.create_genesis_block()
        self.load_blockchain()

    def create_genesis_block(self):
        if not self.chain:
            genesis_block = Block(0, datetime.now().isoformat(), {'message': 'Genesis Block'}, '0')
            self.chain.append(genesis_block)
            self.save_blockchain()

    def get_latest_block(self):
        return self.chain[-1]

    def add_block(self, data):
        previous_block = self.get_latest_block()
        new_block = Block(
            previous_block.index + 1,
            datetime.now().isoformat(),
            data,
            previous_block.hash
        )
        self.chain.append(new_block)
        self.save_blockchain()

    def is_chain_valid(self):
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i - 1]
            if current_block.hash != current_block.calculate_hash():
                return False
            if current_block.previous_hash != previous_block.hash:
                return False
        return True

    def save_blockchain(self):
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
        with open(self.blockchain_file, 'w') as f:
            json.dump([{
                'index': block.index,
                'timestamp': block.timestamp,
                'data': block.data,
                'previous_hash': block.previous_hash,
                'hash': block.hash
            } for block in self.chain], f, indent=2)

    def load_blockchain(self):
        if os.path.exists(self.blockchain_file):
            with open(self.blockchain_file, 'r') as f:
                blocks = json.load(f)
                self.chain = []
                for block_data in blocks:
                    block = Block(
                        block_data['index'],
                        block_data['timestamp'],
                        block_data['data'],
                        block_data['previous_hash']
                    )
                    block.hash = block_data['hash']
                    self.chain.append(block)

class SmartContract:
    def validate_registration(self, user_data, blockchain):
        # Check if National ID is unique
        for block in blockchain.chain:
            if block.data.get('type') == 'registration' and block.data.get('national_id') == user_data['national_id']:
                return False, "National ID already exists"
        # Validate phone (10 digits)
        if not (user_data['phone'].isdigit() and len(user_data['phone']) == 10):
            return False, "Invalid phone number"
        # Validate birth date (simple check for format and past date)
        try:
            birth_date = datetime.strptime(user_data['birth_date'], '%Y-%m-%d')
            if birth_date >= datetime.now():
                return False, "Birth date must be in the past"
        except ValueError:
            return False, "Invalid birth date format"
        return True, "Valid"

    def validate_lab_submission(self, submission_data, blockchain):
        # Check if submitter is a Lab Technician
        lab_user_id = submission_data.get('lab_user_id')
        patient_id = submission_data.get('patient_id')
        lab_exists = False
        patient_exists = False
        for block in blockchain.chain:
            if block.data.get('type') == 'registration':
                if block.data.get('user_id') == lab_user_id and block.data.get('profession') == 'lab':
                    lab_exists = True
                if block.data.get('user_id') == patient_id and block.data.get('profession') == 'patient':
                    patient_exists = True
        if not lab_exists:
            return False, "Submitter is not a valid Lab Technician"
        if not patient_exists:
            return False, "Patient ID does not exist"
        return True, "Valid"